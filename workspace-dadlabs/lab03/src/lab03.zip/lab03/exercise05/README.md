# Title: Lab 03

This directory contains source codes for Lab 03

## Output from Exercise 5

![image](https://github.com/EuniceFoo533/dadrepository/blob/main/workspace-dadlabs/lab03/images/OutputExercise05(1).png)
![image](https://github.com/EuniceFoo533/dadrepository/blob/main/workspace-dadlabs/lab03/images/OutputExercise05(2).png)
