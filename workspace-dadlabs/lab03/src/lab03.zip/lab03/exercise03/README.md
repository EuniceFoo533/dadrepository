# Title: Lab 03

This directory contains source codes for Lab 03

## Output from Exercise 3

![image](https://github.com/EuniceFoo533/dadrepository/blob/main/workspace-dadlabs/lab03/images/OutputExercise03(1).png)
![image](https://github.com/EuniceFoo533/dadrepository/blob/main/workspace-dadlabs/lab03/images/OutputExercise03(2).png)
